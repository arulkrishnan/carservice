package com.cognizant.carservice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;
import javax.net.ssl.CertPathTrustManagerParameters;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.PRIVATE_MEMBER;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.carservice.exception.CarServiceException;
import com.cognizant.carservice.model.AdminDetails;
import com.cognizant.carservice.model.LoginDetails;
import com.cognizant.carservice.model.ServiceCentre;
import com.cognizant.carservice.model.ServiceRequest;
import com.cognizant.carservice.model.ServiceSet;
import com.cognizant.carservice.model.ServiceType;
import com.cognizant.carservice.model.UserDetails;
import com.cognizant.carservice.service.CarService;

@Controller
public class CarServiceController {

	@Resource(name = "carService")
	CarService service;

	public CarServiceController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String home() {
		return "login";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String register() {
		return "signup";
	}

	@RequestMapping(value = "/back", method = RequestMethod.POST)
	public ModelAndView adminhome() throws CarServiceException {
		ModelAndView view = null;
		List<ServiceCentre> list = service.getAllServiceCentre();
		System.out.println(list);
		view = new ModelAndView("adminservice");
		view.addObject("service", list);
		return view;
	}

	@RequestMapping(value = "/backuser", method = RequestMethod.POST)
	public ModelAndView userhome() throws CarServiceException {
		ModelAndView view = null;
		List<ServiceCentre> list = service.getAllServiceCentre();
		System.out.println(list);
		view = new ModelAndView("userservice");
		view.addObject("service", list);
		return view;
	}

	private EntityManager entityManager;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(String id, String password, String type, HttpServletRequest request)
			throws CarServiceException {
		ModelAndView view = null;
		System.out.println(type);
		if (type.compareTo("admin") == 0) {
			LoginDetails details = new LoginDetails();
			details.setId(Integer.parseInt(id));
			details.setPassword(password);
			details.setType(type);
			int login = service.checkLogin(details);
			if (login == 1) {

				HttpSession session = request.getSession();
				session.setAttribute("user", details);
				List<ServiceCentre> list = service.getAllServiceCentre();
				System.out.println(list);
				view = new ModelAndView("adminservice");
				view.addObject("service", list);

			}
		}

		if (type.compareTo("user") == 0) {
			LoginDetails details = new LoginDetails();
			details.setId(Integer.parseInt(id));
			details.setPassword(password);
			details.setType(type);
			int login = service.checkLogin(details);
			if (login == 1) {
				HttpSession session = request.getSession();
				session.setAttribute("user", details);
				List<ServiceCentre> list = service.getAllServiceCentre();
				System.out.println(list);
				view = new ModelAndView("userservice");
				view.addObject("service", list);
			}

		}

		return view;

	}

	@RequestMapping(value = "/registerpage", method = RequestMethod.POST)
	public String registerPage() {
		return "register";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView register(String centreName, String filenames[], String centreAddress, String centreRating,
			String centrePrice, String centreNumber, String centreAvailable, String type[], ModelAndView view)
			throws CarServiceException {
		int id = 0;
		ServiceCentre centre = new ServiceCentre();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < filenames.length; i++) {
			System.out.println(filenames[i]);
			sb.append(filenames[i]).append(",");
		}
		for (int i = 0; i < type.length; i++) {
			System.out.println(type[i]);
		}
		centre.setCentreName(centreName);
		centre.setCentreAddress(centreAddress);
		centre.setCentreAvailable(centreAvailable);
		centre.setCentreNumber(Long.parseLong(centreNumber));
		centre.setCentreRating(Float.parseFloat(centreRating));
		System.out.println(sb.toString());
		Random random = new Random();
		id = random.nextInt(900) + 100;
		centre.setCentreId(id);
		System.out.println("u" + id);
		centre.setCentreImage(sb.toString());
		System.out.println(centre);
		int addservice = service.saveServiceCentre(centre);
		int addtype = service.saveServiceType(type, centre);
		if (addservice == 1 && addtype == 1) {
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);
			System.out.println("saved");
		}

		else {
			System.out.println("Not Saved");
		}
		return view;
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView update(ServiceCentre centre, String[] type) throws CarServiceException {
		ModelAndView view = null;
		System.out.println(centre);
		int addservice = service.saveServiceCentre(centre);
		int flag = service.removeServiceSet(centre.getCentreId());
		int addtype = service.saveServiceType(type, centre);
		if (addservice == 1 && addtype == 1 && flag == 1) {
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);
			System.out.println("saved");
		}
		return view;
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public ModelAndView signup(String firstName, String lastName, String age, String mobile, String gender,
			String password) {
		ModelAndView view = null;
		UserDetails details = new UserDetails();
		Random random = new Random();
		int id = random.nextInt(900) + 100;
		details.setId(id);
		details.setFirstName(firstName);
		details.setLastName(lastName);
		details.setAge(Integer.parseInt(age));
		details.setGender(gender);
		details.setMobile(Long.parseLong(mobile));
		details.setPassword(password);
		System.out.println(details.toString());
		System.out.println(details);
		int count = service.saveUserDetails(details);
		if (count == 1) {
			view = new ModelAndView("login");
			view.addObject("message", "your user id is " + id);
		}

		return view;
	}

	@RequestMapping(value = "/viewcentre", method = RequestMethod.POST)
	public ModelAndView view(String centreId, String Show, String Remove, String Block, String Update)
			throws CarServiceException {

		ModelAndView view = null;
		int cid = Integer.parseInt(centreId);
		int flag, flag1;

		if (Show != null) {
			System.out.println("centreId " + cid);
			List<String> serviceType = service.getServiceTypeById(cid);
			ServiceCentre serviceCentre = service.getAllServiceCentreById(cid);
			System.out.println("controller" + serviceType);
			view = new ModelAndView("viewcentre");
			view.addObject("type", serviceType);
			view.addObject("service", serviceCentre);

		}
		if (Block != null) {
			flag = service.blockServiceCentre(cid);
			if (flag == 1) {
				System.out.println("item blocked!!!");
				List<ServiceCentre> list = service.getAllServiceCentre();
				view = new ModelAndView("adminservice");
				view.addObject("service", list);
			}

		}
		if (Remove != null) {
			flag1 = service.removeServiceSet(cid);
			flag = service.removeServiceCentre(cid);
			if (flag == 1 && flag1 == 1) {
				System.out.println("item removed!!!");
				List<ServiceCentre> list = service.getAllServiceCentre();
				view = new ModelAndView("adminservice");
				view.addObject("service", list);
			}

		}
		if (Update != null) {

			List<String> serviceType = service.getServiceTypeById(cid);
			ServiceCentre serviceCentre = service.getAllServiceCentreById(cid);
			System.out.println("controller" + serviceType);
			view = new ModelAndView("updatecentre");
			view.addObject("type", serviceType);
			view.addObject("service", serviceCentre);

		}

		return view;

	}

	@RequestMapping(value = "/userview", method = RequestMethod.POST)
	public ModelAndView userview(String centreId, String Show) throws CarServiceException {

		ModelAndView view = null;
		int cid = Integer.parseInt(centreId);

		if (Show != null) {
			System.out.println("centreId " + cid);
			List<String> serviceType = service.getServiceTypeById(cid);
			ServiceCentre serviceCentre = service.getAllServiceCentreById(cid);
			System.out.println("controller" + serviceType);
			view = new ModelAndView("takeservice");
			view.addObject("type", serviceType);
			view.addObject("service", serviceCentre);

		}
		return view;

	}

	@RequestMapping(value = "/request", method = RequestMethod.POST)
	public ModelAndView request(String centreId, String[] type, HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		HttpSession httpSession = request.getSession(false);
		LoginDetails details = (LoginDetails) httpSession.getAttribute("user");

		System.out.println("   request " + centreId + " login1 " + details.getId());
		service.requestService(Integer.parseInt(centreId), type, details);
		List<ServiceCentre> list = service.getAllServiceCentre();
		System.out.println("   request " + list);
		view = new ModelAndView("userservice");
		view.addObject("service", list);
		view.addObject("message", "request sent successfully.Please wait for admin to respond");

		return view;

	}

	@RequestMapping(value = "/response", method = RequestMethod.POST)
	public ModelAndView response() throws CarServiceException {

		ModelAndView view = null;
		HashMap<String, String> map = service.getRequest();
		System.out.println(" key values  " + map.keySet());
		view = new ModelAndView("request");
		view.addObject("request", map);

		return view;

	}
	
	@RequestMapping(value = "/payment", method = RequestMethod.POST)
	public ModelAndView payment(String requestId, HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		System.out.println(requestId);
		HttpSession httpSession = request.getSession(false);
		LoginDetails details = (LoginDetails) httpSession.getAttribute("user");
		service.payment(Integer.parseInt(requestId),details);
		List<ServiceCentre> list = service.getAllServiceCentre();
		System.out.println("   request " + list);
		view = new ModelAndView("userservice");
		view.addObject("service", list);
		view.addObject("payment", "Payment is successfull");

		return view;

	}

	
	@RequestMapping(value = "/requestStatus", method = RequestMethod.POST)
	public ModelAndView requestStatus(HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		HttpSession httpSession = request.getSession(false);
		LoginDetails details = (LoginDetails) httpSession.getAttribute("user");
		List<ServiceRequest> list = service.requestStatus(details.getId());
			view = new ModelAndView("response");
			view.addObject("requestList", list);
		
		
		return view;

	}

	@RequestMapping(value = "/history", method = RequestMethod.POST)
	public ModelAndView history(HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		

		return view;

	}
	
	@RequestMapping(value = "/acceptordecline", method = RequestMethod.POST)
	public ModelAndView acceptordecline(String centreName, String Accept, String Reject) throws CarServiceException {

		ModelAndView view = null;
		System.out.println(centreName);
		if (Accept != null) {
			service.responseService(centreName, 2);
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);
		}
		if (Reject != null) {
			service.responseService(centreName, 3);
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);
		}

		return view;

	}

	@RequestMapping(value = "/LogoutController", method = RequestMethod.GET)
	public String logoutController(ModelAndView modelAndView, HttpServletRequest request) throws CarServiceException {

		HttpSession httpSession = request.getSession(false);
		httpSession.invalidate();
		return "redirect:home";
	}

}

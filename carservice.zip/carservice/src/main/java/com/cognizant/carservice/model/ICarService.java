package com.cognizant.carservice.model;

import java.util.HashMap;
import java.util.List;

import com.cognizant.carservice.exception.CarServiceException;

public interface ICarService {

	int saveServiceCentre(ServiceCentre centre) throws CarServiceException;

	int getAttempt(String username) throws CarServiceException;

	int updateAttempt(String username, int status) throws CarServiceException;

	List<ServiceCentre> getAllServiceCentre() throws CarServiceException;
	
	ServiceCentre getAllServiceCentreById(int cid) throws CarServiceException;

	List<String> getServiceTypeById(int pid) throws CarServiceException;

	int blockServiceCentre(int cid) throws CarServiceException;

	int removeServiceCentre(int cid) throws CarServiceException;
	
	int removeServiceSet(int cid) throws CarServiceException;

	
	int requestService(int cid,String[] type,LoginDetails details);

	HashMap<String, String>  getRequest();

	List<ServiceRequest> requestStatus(int uid);
	
	int responseService(String cname,int request);

	int checkUsername(String username) throws CarServiceException;

	int checkLogin(LoginDetails loginDetails) throws CarServiceException;

	int saveUserDetails(UserDetails details);
	
	int saveServiceType(String type[],ServiceCentre centre);
	
	int payment(int rid,LoginDetails details);
	
	List<ServicePayment> history(int id);
	

}

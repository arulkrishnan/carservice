package com.cognizant.carservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="service_request")
public class ServiceRequest {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="sr_id")
	private int requestId;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="sc_id_fk")
	private ServiceCentre centre;
	
	@Column(name="sr_types")
	private String requestTypes;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="id_fk")
	private LoginDetails details;
	
	@Column(name="sr_price")
	private double requestPrice;
	
	@Column(name="sr_request")
	private int requestStatus;
	
	public ServiceRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceRequest(int requestId, ServiceCentre centre, String requestTypes, LoginDetails details,
			double requestPrice, int requestStatus) {
		super();
		this.requestId = requestId;
		this.centre = centre;
		this.requestTypes = requestTypes;
		this.details = details;
		this.requestPrice = requestPrice;
		this.requestStatus = requestStatus;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public ServiceCentre getCentre() {
		return centre;
	}

	public void setCentre(ServiceCentre centre) {
		this.centre = centre;
	}

	public String getRequestTypes() {
		return requestTypes;
	}

	public void setRequestTypes(String requestTypes) {
		this.requestTypes = requestTypes;
	}

	public LoginDetails getDetails() {
		return details;
	}

	public void setDetails(LoginDetails details) {
		this.details = details;
	}

	public double getRequestPrice() {
		return requestPrice;
	}

	public void setRequestPrice(double requestPrice) {
		this.requestPrice = requestPrice;
	}

	public int getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(int requestStatus) {
		this.requestStatus = requestStatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((centre == null) ? 0 : centre.hashCode());
		result = prime * result + ((details == null) ? 0 : details.hashCode());
		result = prime * result + requestId;
		long temp;
		temp = Double.doubleToLongBits(requestPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + requestStatus;
		result = prime * result + ((requestTypes == null) ? 0 : requestTypes.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceRequest other = (ServiceRequest) obj;
		if (centre == null) {
			if (other.centre != null)
				return false;
		} else if (!centre.equals(other.centre))
			return false;
		if (details == null) {
			if (other.details != null)
				return false;
		} else if (!details.equals(other.details))
			return false;
		if (requestId != other.requestId)
			return false;
		if (Double.doubleToLongBits(requestPrice) != Double.doubleToLongBits(other.requestPrice))
			return false;
		if (requestStatus != other.requestStatus)
			return false;
		if (requestTypes == null) {
			if (other.requestTypes != null)
				return false;
		} else if (!requestTypes.equals(other.requestTypes))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ServiceRequest [requestId=" + requestId + ", centre=" + centre + ", requestTypes=" + requestTypes
				+ ", details=" + details + ", requestPrice=" + requestPrice + ", requestStatus=" + requestStatus + "]";
	}

	

}

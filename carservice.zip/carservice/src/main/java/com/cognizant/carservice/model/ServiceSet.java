package com.cognizant.carservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="service_set")
public class ServiceSet {

	

	@Id
	@Column(name="ss_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer setId;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="sc_id_fk")
	private ServiceCentre centre;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="st_id_fk")
	private ServiceType type;
	
	public ServiceSet() {
		// TODO Auto-generated constructor stub
	}

	public ServiceSet(Integer setId, ServiceCentre centre, ServiceType type) {
		super();
		this.setId = setId;
		this.centre = centre;
		this.type = type;
	}

	public Integer getSetId() {
		return setId;
	}

	public void setSetId(Integer setId) {
		this.setId = setId;
	}

	public ServiceCentre getCentre() {
		return centre;
	}

	public void setCentre(ServiceCentre centre) {
		this.centre = centre;
	}

	public ServiceType getType() {
		return type;
	}

	public void setType(ServiceType type) {
		this.type = type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((centre == null) ? 0 : centre.hashCode());
		result = prime * result + ((setId == null) ? 0 : setId.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceSet other = (ServiceSet) obj;
		if (centre == null) {
			if (other.centre != null)
				return false;
		} else if (!centre.equals(other.centre))
			return false;
		if (setId == null) {
			if (other.setId != null)
				return false;
		} else if (!setId.equals(other.setId))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ServiceSet [setId=" + setId + ", centre=" + centre + ", type=" + type + "]";
	}
}

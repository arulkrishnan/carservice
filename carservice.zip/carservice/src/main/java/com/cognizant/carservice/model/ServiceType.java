package com.cognizant.carservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="service_type")
public class ServiceType {

	@Id
	@Column(name="st_id")
	private int typId;
	@Column(name="st_name")
	private String typeName;
	@Column(name="st_price")
	private Double price;
	
	public ServiceType(int typId, String typeName, double price) {
		super();
		this.typId = typId;
		this.typeName = typeName;
		this.price = price;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public ServiceType() {
		// TODO Auto-generated constructor stub
	}

	public ServiceType(int typId, String typeName) {
		super();
		this.typId = typId;
		this.typeName = typeName;
	}

	public int getTypId() {
		return typId;
	}

	public void setTypId(int typId) {
		this.typId = typId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + typId;
		result = prime * result + ((typeName == null) ? 0 : typeName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceType other = (ServiceType) obj;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (typId != other.typId)
			return false;
		if (typeName == null) {
			if (other.typeName != null)
				return false;
		} else if (!typeName.equals(other.typeName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ServiceType [typId=" + typId + ", typeName=" + typeName + ", price=" + price + "]";
	}

	
}

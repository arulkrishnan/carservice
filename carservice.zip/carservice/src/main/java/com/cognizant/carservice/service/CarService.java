package com.cognizant.carservice.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.carservice.exception.CarServiceException;
import com.cognizant.carservice.model.ICarService;
import com.cognizant.carservice.model.LoginDetails;
import com.cognizant.carservice.model.ServiceCentre;
import com.cognizant.carservice.model.ServicePayment;
import com.cognizant.carservice.model.ServiceRequest;
import com.cognizant.carservice.model.ServiceSet;
import com.cognizant.carservice.model.ServiceType;
import com.cognizant.carservice.model.UserDetails;

@Service("carService")
public class CarService implements ICarService {

	@Autowired
	ICarService carServiceDao;
	
	public CarService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int checkLogin(LoginDetails loginDetails) throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.checkLogin(loginDetails);
	}

	@Override
	public int checkUsername(String username) throws CarServiceException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateAttempt(String username, int status) throws CarServiceException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getAttempt(String username) throws CarServiceException {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public int saveServiceCentre(ServiceCentre centre) throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.saveServiceCentre(centre);
	}

	@Override
	public List<ServiceCentre> getAllServiceCentre() throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.getAllServiceCentre();
	}

	@Override
	public HashMap<String, String>  getRequest() {
		// TODO Auto-generated method stub
		return carServiceDao.getRequest();
	}

	@Override
	public int responseService(String cname,int request) {
		// TODO Auto-generated method stub
		return carServiceDao.responseService(cname,request);
	}


	public int saveUserDetails(UserDetails details) {
		// TODO Auto-generated method stub
		return carServiceDao.saveUserDetails(details);
	}

	@Override
	public int saveServiceType(String[] type, ServiceCentre centre) {
		// TODO Auto-generated method stub
		return carServiceDao.saveServiceType(type, centre);
	}

	@Override
	public List<String> getServiceTypeById(int cid) throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.getServiceTypeById(cid);
	}

	@Override
	public ServiceCentre getAllServiceCentreById(int cid) throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.getAllServiceCentreById(cid);
	}

	@Override
	public int blockServiceCentre(int cid) throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.blockServiceCentre(cid);
	}

	@Override
	public int removeServiceCentre(int cid) throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.removeServiceCentre(cid);
	}

	@Override
	public int removeServiceSet(int cid) throws CarServiceException {
		// TODO Auto-generated method stub
		return carServiceDao.removeServiceSet(cid);
	}

	@Override
	public int requestService(int cid, String[] type,LoginDetails details) {
		// TODO Auto-generated method stub
		return carServiceDao.requestService(cid, type,details);
	}

	@Override
	public List<ServiceRequest> requestStatus(int uid) {
		// TODO Auto-generated method stub
		return carServiceDao.requestStatus(uid);
	}

	@Override
	public int payment(int rid,LoginDetails details) {
		// TODO Auto-generated method stub
		return carServiceDao.payment(rid,details);
		
	}

	@Override
	public List<ServicePayment> history(int id) {
		// TODO Auto-generated method stub
		return carServiceDao.history(id);
	}

	

}
